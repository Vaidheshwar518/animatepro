
document.getElementById("adminTrigger").addEventListener("input", function () {
  if (this.value === "throsh@1518") {
    document.getElementById("adminMode").classList.remove("hidden");
  }
});

document.getElementById("toggleAdmin").addEventListener("click", function () {
  const state = document.getElementById("adminState");
  if (state.textContent === "OFF") {
    state.textContent = "ON";
    this.style.backgroundColor = "#0f0";
  } else {
    state.textContent = "OFF";
    this.style.backgroundColor = "#0ff";
  }
});
